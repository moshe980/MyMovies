package iob.myMovies;

import iob.boundary.ActivityBoundary;

public interface DoesSomething {
	
	public Object doSomthing(ActivityBoundary activityBoundary);
	


}
