package iob.data;

public enum CreationWindow {
	
	LAST_HOUR,LAST_24_HOURS,LAST_7_DAYS,LAST_30_DAYS

}
